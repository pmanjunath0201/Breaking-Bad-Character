const Header = () => {
  return (
    <header>
      <h1>
        <span>Br</span>eaking
      </h1>
      <h1>
        <span className="ba">Ba</span>d
      </h1>
    </header>
  );
}

export default Header